vti_encoding:SR|utf8-nl
vti_timelastmodified:TW|09 Dec 2014 16:26:27 -0000
vti_author:SR|PC\\dan
vti_modifiedby:SR|PC\\dan
vti_nexttolasttimemodified:TW|09 Dec 2014 16:26:27 -0000
vti_timecreated:TR|14 Dec 2014 13:19:47 -0000
vti_cacheddtm:TX|14 Dec 2014 13:19:47 -0000
vti_filesize:IR|2
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|index.php profile.php friend.php Template.dwt editprofile.php home.php register.php search.php 404.php pictures.php
vti_syncwith_ftp.wisp-r.com\:21/%2f:TX|14 Dec 2014 13:19:47 -0000
vti_syncofs_ftp.wisp-r.com\:21/%2f:TW|19 Dec 2014 10:05:16 -0000
