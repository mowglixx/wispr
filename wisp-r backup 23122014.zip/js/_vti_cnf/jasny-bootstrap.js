vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Dec 2014 11:47:42 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|
vti_author:SR|PC\\dan
vti_modifiedby:SR|PC\\dan
vti_timecreated:TR|19 Dec 2014 11:47:42 -0000
vti_cacheddtm:TX|19 Dec 2014 11:47:42 -0000
vti_filesize:IR|30938
vti_syncwith_ftp.wisp-r.com\:21/%2f:TR|19 Dec 2014 11:47:42 -0000
vti_syncofs_ftp.wisp-r.com\:21/%2f:TW|19 Dec 2014 11:51:27 -0000
